import React from 'react'

const IndividualSelectInput = () => {
  return (
    <div>IndividualSelectInput</div>
  )
}

export default IndividualSelectInput