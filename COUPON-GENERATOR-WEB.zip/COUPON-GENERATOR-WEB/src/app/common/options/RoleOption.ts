export const roles = [
    { key: 'Admin', text: 'Admin', value: '1' },
    { key: 'Business', text: 'Business', value: '2' },
    { key: 'Customer Experience', text: 'Customer Experience', value: '3' },
  ];