export const statusValue = [
    { key: 'Yes', text: 'Yes', value: true },
    { key: 'No', text: 'No', value: false },
  ];