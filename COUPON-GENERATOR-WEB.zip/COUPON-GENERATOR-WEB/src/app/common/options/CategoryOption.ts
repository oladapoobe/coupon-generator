export const categories = [
    { key: 'Entertainment', text: 'Entertainment', value: 0 },
    { key: 'Internet', text: 'Internet', value: 1 },
    { key: 'Travel', text: 'Travel', value: 2 },
    { key: 'Life Style', text: 'Life Style', value: 3 },
  ];

